# 기능 목록 수정
1. test upload
2. test buy
3. 장바구니 담기
4. 디테일 페이지 보여주기